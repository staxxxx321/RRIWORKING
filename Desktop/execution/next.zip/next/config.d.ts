import getConfig from './dist/shared/lib/runtime-config.external'
export * from './dist/shared/lib/runtime-config.external'
export default getConfig
