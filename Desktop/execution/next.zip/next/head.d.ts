import Head from './dist/shared/lib/head'
export * from './dist/shared/lib/head'
export default Head
