module.exports = require('../dist/client/compat/router')
